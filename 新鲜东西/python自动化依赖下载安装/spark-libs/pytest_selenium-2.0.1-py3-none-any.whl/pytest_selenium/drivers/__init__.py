from . import internet_explorer as ie  # noqa
